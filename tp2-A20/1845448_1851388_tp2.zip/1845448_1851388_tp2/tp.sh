#!/bin/sh

python prototype/main.py "$@"
