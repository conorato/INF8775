#!/bin/sh

python src/main.py "$@"
